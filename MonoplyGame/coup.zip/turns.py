#ask for cards to use
#ask if any1 challenges card
#1. Player takes income+ foreign aid
#1.3 Others can use duke to stop foreign aid
#1.6 Player can challenge duke or lose foreign aid
#2 Player uses card 
#3 Others can challenge card
#3.3 Choose to assassinate, can challenge
#3.6 Choose to block with contessa, can challenge
#Action goes through

